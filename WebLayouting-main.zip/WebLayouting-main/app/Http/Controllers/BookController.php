<?php

namespace App\Http\Controllers;

use App\Models\Book;
use Illuminate\Http\Request;

class BookController extends Controller
{
    public function index()
    {
        return view('buku', ['books' => Book::all()]);
    }

    public function create()
    {
        return view('create');
    }

    public function store(Request $request)
    {
        Book::create($request->validate([
            'kode_buku' => 'required|unique:books',
            'judul_buku' => 'required',
            'nama_penulis' => 'required',
            'kategori' => 'required',
            'stok' => 'required|integer',
        ]));

        return redirect()->route('books.index');
    }

    public function edit(Book $book)
    {
        return view('edit', compact('book'));
    }

    public function update(Request $request, Book $book)
    {
        $book->update($request->validate([
            'kode_buku' => 'required|unique:books,kode_buku,'.$book->id,
            'judul_buku' => 'required',
            'nama_penulis' => 'required',
            'kategori' => 'required',
            'stok' => 'required|integer',
        ]));

        return redirect()->route('books.index');
    }

    public function destroy(Book $book)
    {
        $book->delete();
        return redirect()->route('books.index');
    }
}