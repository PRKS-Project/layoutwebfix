<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="alert alert-success">
        Selamat datang, <?php echo e(Auth::user()->name); ?>!
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\WebLayouting-main\resources\views/dashboard.blade.php ENDPATH**/ ?>