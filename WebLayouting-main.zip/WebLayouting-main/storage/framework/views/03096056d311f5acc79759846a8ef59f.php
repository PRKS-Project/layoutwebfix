<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
  <main id="main" class="main">
    <div class="row">
      <div class="card info-card sales-card">
        <?php echo $__env->yieldContent('content'); ?>
      </div>
    </div>
  </main><!-- End #main -->
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\WebLayouting-main\resources\views/layouts/main.blade.php ENDPATH**/ ?>