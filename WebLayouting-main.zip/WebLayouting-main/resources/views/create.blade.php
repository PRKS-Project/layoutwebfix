@extends('layouts.main')

@section('content')
    <div class="pagetitle">
        <h1>Tambah Buku</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="{{ route('books.index') }}">Home</a></li>
                <li class="breadcrumb-item active">Tambah Buku</li>
            </ol>
        </nav>
    </div>

    <div class="container">
        <h2>Silahkan Isi Data Buku</h2>
        <form action="{{ route('books.store') }}" method="POST">
            @csrf
            <div class="form-group">
                <label for="kode_buku">Kode Buku:</label>
                <input type="text" name="kode_buku" id="kode_buku" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="judul_buku">Judul Buku:</label>
                <input type="text" name="judul_buku" id="judul_buku" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="nama_penulis">Nama Penulis:</label>
                <input type="text" name="nama_penulis" id="nama_penulis" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="kategori">Kategori:</label>
                <input type="text" name="kategori" id="kategori" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="stok">Stok:</label>
                <input type="number" name="stok" id="stok" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary mt-3">Simpan</button>
        </form>
    </div>
@endsection
